# ROS DeviceShifu Demo

This is a demo project that shows how to integrate ROS (Robot Operating System) with deviceShifu using the [goroslib](https://github.com/bluenviron/goroslib) package.

## Prerequisites

- Go 1.21 or later
- Docker
- ROS (Robot Operating System) installed and running
- deviceShifu environment set up

## Features

- ROS node that publishes data to the `device_shifu_data` topic
- Subscribes to commands from the `device_shifu_commands` topic
- Containerized deployment

## Building and Running

### Local Development

1. Make sure ROS is running:
```bash
roscore
```

2. Build and run the application:
```bash
go mod tidy
go run main.go
```

### Docker Deployment

1. Build the Docker image:
```bash
docker build -t ros-device-shifu .
```

2. Run the container:
```bash
docker run --network host ros-device-shifu
```

## Testing

1. In a new terminal, subscribe to the data topic:
```bash
rostopic echo /device_shifu_data
```

2. In another terminal, publish a command:
```bash
rostopic pub /device_shifu_commands std_msgs/String "data: 'test command'"
```

## Integration with deviceShifu

This demo can be integrated with deviceShifu by:
1. Configuring the ROS node as a deviceShifu device
2. Using the ROS topics as communication channels
3. Implementing the necessary deviceShifu interfaces

## License

This project is licensed under the MIT License - see the LICENSE file for details. 
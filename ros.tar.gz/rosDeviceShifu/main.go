package main

import (
	"log"
	"net"
	"os"
	"time"

	"github.com/bluenviron/goroslib/v2"
	"github.com/bluenviron/goroslib/v2/pkg/msgs/nav_msgs"
	"github.com/bluenviron/goroslib/v2/pkg/msgs/std_msgs"
)

func getLocalIP() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "localhost"
	}
	for _, address := range addrs {
		if ipnet, ok := address.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String()
			}
		}
	}
	return "localhost"
}

func main() {
	// Configure logging
	log.SetOutput(os.Stdout)
	log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds | log.Lshortfile)
	log.Println("Starting ROS DeviceShifu node...")

	// Get local IP address
	localIP := getLocalIP()
	log.Printf("Local IP address: %s", localIP)

	// Set ROS environment variables
	os.Setenv("ROS_MASTER_URI", "http://192.168.3.102:11311")
	os.Setenv("ROS_IP", localIP)
	os.Setenv("ROS_HOSTNAME", localIP)

	log.Printf("ROS_MASTER_URI: %s", os.Getenv("ROS_MASTER_URI"))
	log.Printf("ROS_IP: %s", os.Getenv("ROS_IP"))

	// Create a node with explicit network configuration
	log.Println("Connecting to ROS master...")
	n, err := goroslib.NewNode(goroslib.NodeConf{
		Name:          "device_shifu_ros_node",
		MasterAddress: "192.168.3.102:11311",
		Host:          localIP,
	})
	if err != nil {
		log.Fatalf("Failed to create ROS node: %v", err)
	}
	defer n.Close()
	log.Println("Successfully connected to ROS master")

	// Create a publisher
	log.Println("Creating publisher for device_shifu_data topic...")
	pub, err := goroslib.NewPublisher(goroslib.PublisherConf{
		Node:  n,
		Topic: "device_shifu_data",
		Msg:   &std_msgs.String{},
	})
	if err != nil {
		log.Fatalf("Failed to create publisher: %v", err)
	}
	defer pub.Close()
	log.Println("Publisher created successfully")

	// Create a subscriber with retry logic
	var sub *goroslib.Subscriber
	maxRetries := 5
	retryDelay := time.Second * 2

	for i := 0; i < maxRetries; i++ {
		log.Printf("Attempting to create subscriber for odom topic (attempt %d/%d)...", i+1, maxRetries)
		sub, err = goroslib.NewSubscriber(goroslib.SubscriberConf{
			Node:  n,
			Topic: "/odom",
			Callback: func(msg *nav_msgs.Odometry) {
				log.Printf("Received odometry data - Position: x=%.2f, y=%.2f, z=%.2f",
					msg.Pose.Pose.Position.X,
					msg.Pose.Pose.Position.Y,
					msg.Pose.Pose.Position.Z)
			},
		})
		if err == nil {
			break
		}
		log.Printf("Failed to create subscriber (attempt %d/%d): %v", i+1, maxRetries, err)
		if i < maxRetries-1 {
			time.Sleep(retryDelay)
		}
	}

	if err != nil {
		log.Fatalf("Failed to create subscriber after %d attempts: %v", maxRetries, err)
	}
	defer sub.Close()
	log.Println("Subscriber created successfully")

	// Publish data periodically
	log.Println("Starting periodic data publishing...")
	ticker := time.NewTicker(1 * time.Second)
	for range ticker.C {
		msg := &std_msgs.String{
			Data: "Hello from deviceShifu ROS node!",
		}
		pub.Write(msg)
		log.Printf("Published message: %s", msg.Data)
	}
}
